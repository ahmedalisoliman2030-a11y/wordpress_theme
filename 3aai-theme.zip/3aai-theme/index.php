<?php
/**
 * Main template file
 *
 * This file is required for WordPress theme compatibility.
 * The theme uses block templates for rendering.
 *
 * @package 3AAi-Theme
 * @since 1.0.0
 */

// Silence is golden.
